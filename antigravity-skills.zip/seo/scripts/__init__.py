"""Agentic SEO script package."""
