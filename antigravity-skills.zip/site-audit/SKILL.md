---
name: site-audit
description: >
  Full multi-agent site audit skill. Use this when the user provides a website
  URL and asks to "audit", "review", "analyze", "check", or "report on" a site.
  Spawns four specialist agents (Aria, Blaze, Scout, Vega) in parallel and
  compiles a single consolidated report with every finding, its direct effect,
  and priority. No changes are made to any files.
triggers:
  - "audit [url]"
  - "site audit [url]"
  - "review [url]"
  - "site report [url]"
  - "analyze [url]"
  - "check [url]"
  - "run report on [url]"
---

# Site Audit Skill

Full multi-agent site analysis. Spawns four specialist read-only agents, collects all findings, and compiles a prioritized consolidated report. Zero changes are made to the site.

## When to Activate

Activate this skill whenever the user provides a URL with any of these intents:
- "audit this site", "run a report", "review my site", "check this website"
- "what's wrong with [url]", "analyze [url]", "give me a site report"

## Execution Workflow

### Step 1 — Scan the site structure
Before launching agents, read enough of the project to understand what you're auditing:
```
- Identify all page files (src/pages/ or equivalent)
- Identify components directory
- Identify layout/template files
- Identify CSS/style files
- Identify public assets directory
- Identify config files (astro.config, next.config, robots.txt, etc.)
- Identify any existing schema or SEO configuration
```

### Step 2 — Define the four analyst agents

Use `define_subagent` to create a read-only analyst type (write tools disabled):
```
name: site-audit-analyst
enable_write_tools: false
system_prompt: "You are a read-only site analyst. Analyze thoroughly and report findings. Make NO file changes."
```

### Step 3 — Launch all four agents in parallel

Invoke all four with `invoke_subagent`. Each agent reads the site source independently.

#### Aria [UI/UX Analyst]
Prompt focus areas:
1. **Design System** — color palette consistency, typography scale, CSS variables, font choices
2. **Visual Quality** — rate 1-10, check for gradients, glassmorphism, animations, hover effects
3. **Responsive Design** — breakpoints used, mobile-first vs desktop-first, overflow risks
4. **Component Structure** — duplication, reusability, naming conventions
5. **Semantic HTML** — one H1 per page, heading hierarchy (h1→h2→h3), semantic elements
6. **Accessibility** — alt text, focus states, ARIA labels, keyboard navigation
7. **Animation & Interaction** — micro-animations, transitions, missing UX affordances
8. **Missing pages/sections** — what would be expected for this type of business/site that's absent

Output format per finding:
```
**[ARIA] Finding:** [issue]
**Why:** [why it matters for UX]
**Direct Effect:** [what happens to users/business]
**Priority:** Critical / High / Medium / Low
```

#### Blaze [Performance Analyst]
Prompt focus areas:
1. **Images** — `width`/`height` attrs (CLS), `loading="lazy"`, `fetchpriority="high"` on LCP, file formats (WebP/AVIF vs JPG/PNG), file sizes
2. **Core Web Vitals Risk** — specific LCP threats (>2.5s), INP threats (>200ms), CLS threats (>0.1). **NOTE: FID is retired — INP only.**
3. **JavaScript** — render-blocking scripts, unnecessary JS, Astro/Next hydration strategy
4. **CSS** — render-blocking stylesheets, bloated global CSS, unused rules
5. **Fonts** — `font-display: swap`, preload hints, render-blocking font requests, FOUT/FOIT
6. **Framework Config** — optimization settings, image pipeline, static vs SSR
7. **Third-party Scripts** — synchronous externals, iframe dependencies, CDN resources
8. **Asset Optimization** — raw file sizes, missing compression, unused public assets

Output format per finding:
```
**[BLAZE] Finding:** [issue]
**Why:** [why it affects load speed]
**Direct Effect:** [specific LCP/INP/CLS impact or ms estimate]
**Priority:** Critical / High / Medium / Low
```

#### Scout [SEO Analyst]
**Load before starting:** `C:\Users\user\.gemini\antigravity\skills\seo\SKILL.md`
**Rubric:** `C:\Users\user\.gemini\antigravity\skills\seo\resources\references\llm-audit-rubric.md`

Prompt focus areas:
1. **Title Tags** — unique, 50-60 chars, keyword-first per page
2. **Meta Descriptions** — present, 150-160 chars, compelling
3. **Heading Structure** — single H1 per page, correct hierarchy, keyword usage
4. **Structured Data** — JSON-LD present and valid, appropriate types for site category (LocalBusiness, Article, Product, etc.). FAQPage restricted to gov/healthcare only. HowTo deprecated. JSON-LD only.
5. **Open Graph / Social** — og:title, og:description, og:image, og:url, og:type, twitter:card
6. **robots.txt** — correctly configured, AI crawlers (GPTBot, ClaudeBot, PerplexityBot, Google-Extended, Applebot-Extended) policy
7. **Sitemap** — present, configured, linked in head
8. **Canonical Tags** — present on all pages
9. **Image Alt Text** — meaningful descriptions on all images
10. **Local SEO** (if applicable) — NAP consistency, service area pages, address schema
11. **AI Search Readiness** — `llms.txt`, direct-answer content, Q&A structured headings
12. **E-E-A-T** — trust signals, credentials, reviews, author info

Output format per finding:
```
**[SCOUT] Finding:** [issue]
**Evidence:** [specific code/element/line]
**Why:** [impact on search rankings]
**Direct Effect:** [ranking / indexability / CTR impact]
**Priority:** 🔴 Critical / ⚠️ Warning / ✅ Pass / ℹ️ Info
```

#### Vega [QA Analyst]
Prompt focus areas:
1. **Navigation Links** — all nav/footer links point to existing routes; no 404s
2. **Form Validation** — required fields, input types, pattern validation, server handling
3. **Accessibility (a11y)** — alt text, labels, ARIA roles, keyboard nav, skip links, focus states, iframe titles
4. **Responsiveness** — fixed widths, overflow risks, breakpoint coverage
5. **Content Quality** — placeholder text, lorem ipsum, wrong business names, copy-paste artifacts
6. **Cross-page Consistency** — layout wrapper used on all pages, nav/footer consistent
7. **Dynamic Routes** — edge cases, 404 handling for unknown slugs
8. **Build/Runtime Issues** — likely Astro/Next warnings, deprecated APIs, prop mismatches
9. **Contact Links** — `tel:` and `mailto:` links present and consistent with config/business data

Output format per finding:
```
**[VEGA] Finding:** [issue]
**Location:** [file + line number]
**Why:** [why it's a problem]
**Direct Effect:** [user/reliability impact]
**Priority:** Critical / High / Medium / Low
```

### Step 4 — Wait for all agents to report back

Do not compile the report until all four agents have sent their findings. If an agent fails due to rate limits, re-launch it individually and wait.

### Step 5 — Compile the consolidated report

Write the consolidated report to an artifact file named `site-audit-report.md`. Structure it as:

```markdown
# [Site Name] — Full Site Audit Report
**Agents:** Aria [UI/UX] · Blaze [Performance] · Scout [SEO] · Vega [QA]
**URL Audited:** [url]
**Mode:** Read-only — zero changes made
**SEO Score:** [Scout's composite score]/100
**Date:** [today's date]

---

## 🔴 CRITICAL — Fix Immediately
[All Critical findings from all agents, each with: what it is, why it matters, direct effect]

## ⚠️ HIGH — Fix Before Launch
[All High findings]

## ℹ️ MEDIUM — Significant Improvements
[Summary table of Medium findings]

## 🔵 LOW — Polish When Time Allows
[Summary table of Low findings]

## 📊 Score Summary by Category
[Table with category scores]

## ✅ What's Already Good
[Confirmed passing items from all agents]

---
*Report generated by: Aria [UI/UX] · Blaze [Performance] · Scout [SEO] · Vega [QA] — no changes made*
```

### Step 6 — Present to user

After writing the artifact, summarize:
1. Total findings by severity (X Critical, Y High, Z Medium, W Low)
2. Top 3 most urgent issues in plain language
3. Overall SEO score with one-sentence explanation
4. Point user to the artifact for full details
5. Ask if they want the team to start implementing fixes

## SEO Skill Reference

The Scout agent uses the full Agentic SEO Skill pack:
- **Skill entry point:** `C:\Users\user\.gemini\antigravity\skills\seo\SKILL.md`
- **Sub-skills:** `C:\Users\user\.gemini\antigravity\skills\seo\resources\skills\`
- **Evidence scripts:** `C:\Users\user\.gemini\antigravity\skills\seo\scripts\`
- **Rubric:** `C:\Users\user\.gemini\antigravity\skills\seo\resources\references\llm-audit-rubric.md`
- **Full registry:** `C:\Users\user\.gemini\antigravity\skills\registry.md`

For live URL audits (when a deployed URL is provided rather than local source):
```bash
SKILL=C:\Users\user\.gemini\antigravity\skills\seo\scripts

# Fetch and parse the live page
python3 %SKILL%\fetch_page.py [url] --output page.html
python3 %SKILL%\parse_html.py page.html --url [url] --json

# Core Web Vitals
python3 %SKILL%\pagespeed.py [url] --strategy mobile
python3 %SKILL%\pagespeed.py [url] --strategy desktop

# Technical checks
python3 %SKILL%\robots_checker.py [url]
python3 %SKILL%\sitemap_checker.py [url]
python3 %SKILL%\broken_links.py [url] --workers 5
python3 %SKILL%\validate_schema.py page.html
python3 %SKILL%\social_meta.py [url]
python3 %SKILL%\security_headers.py [url]
python3 %SKILL%\redirect_checker.py [url]
python3 %SKILL%\internal_links.py [url] --depth 2 --max-pages 20
python3 %SKILL%\indexability_matrix.py [url] --max-pages 20
```

## Critical Rules

1. **Read-only always** — agents must NEVER create, edit, or delete any files
2. **INP not FID** — FID was retired September 9, 2024; only reference INP
3. **FAQPage schema restricted** — government/healthcare only; flag if used on commercial sites
4. **HowTo schema deprecated** — flag if found anywhere
5. **JSON-LD only** — flag any Microdata or RDFa recommendations
6. **E-E-A-T is universal** — applies to ALL competitive queries as of December 2025
7. **Re-launch rate-limited agents** — if an agent fails (429), re-launch individually rather than aborting
8. **Wait for all four** — do not compile until all agents report back
9. **Always write artifact** — the report must be saved as `site-audit-report.md`
10. **Confidence labels on SEO findings** — `Confirmed` (from source code), `Likely` (from structure), `Hypothesis` (inferred)
