# 🧠 Antigravity Skills Registry

All skills stored here are globally reusable — attach them to any agent system by referencing the paths below.

---

## 📦 Available Skill Packs

### `site-audit` — Full Multi-Agent Site Audit ⭐ GLOBAL ACTION
> Skill file: `C:\Users\user\.gemini\antigravity\skills\site-audit\SKILL.md`

**How to use:** Provide any website URL and say "audit", "site report", "review", or "analyze".
Launches four specialist agents in parallel (Aria, Blaze, Scout, Vega) and compiles a single consolidated report. Zero changes made to any files.

**Triggers:** `audit [url]` · `site audit [url]` · `site report [url]` · `review [url]` · `analyze [url]`

**Output:** `site-audit-report.md` artifact with all findings organized by Critical → High → Medium → Low, each with direct effects explained.

**Agents invoked:**
| Agent | Role |
|---|---|
| Aria [UI/UX Analyst] | Design system, responsiveness, accessibility, missing pages |
| Blaze [Performance Analyst] | Images, Core Web Vitals (LCP/INP/CLS), fonts, JS, CSS |
| Scout [SEO Analyst] | Titles, schema, OG tags, robots, E-E-A-T, AI search readiness |
| Vega [QA Analyst] | Broken links, form validation, a11y, cross-page consistency |

---

### `seo` — Agentic SEO Skill
> Source: https://github.com/Bhanunamikaze/Agentic-SEO-Skill
> Location: `C:\Users\user\.gemini\antigravity\skills\seo\`

LLM-first SEO analysis with 16 sub-skills, 10 specialist agents, and 89 evidence-collection scripts.

| Sub-Skill File | Purpose |
|---|---|
| `resources/skills/seo-audit.md` | Full website audit with evidence-backed scoring |
| `resources/skills/seo-page.md` | Deep single-page analysis |
| `resources/skills/seo-technical.md` | Crawlability, indexability, Core Web Vitals, AI crawlers |
| `resources/skills/seo-content.md` | Content quality & E-E-A-T assessment |
| `resources/skills/seo-schema.md` | Schema.org detection, validation & JSON-LD generation |
| `resources/skills/seo-sitemap.md` | XML sitemap analysis & generation |
| `resources/skills/seo-images.md` | Image optimization audit (alt text, formats, lazy loading) |
| `resources/skills/seo-geo.md` | Generative Engine Optimization — AI Overviews, ChatGPT, Perplexity |
| `resources/skills/seo-aeo.md` | Answer Engine Optimization — Featured Snippets, PAA |
| `resources/skills/seo-links.md` | Internal links, backlinks, anchor text, orphan pages |
| `resources/skills/seo-plan.md` | Strategic SEO planning with topical clusters |
| `resources/skills/seo-article.md` | Article data extraction & content optimization |
| `resources/skills/seo-hreflang.md` | International SEO / hreflang validation |
| `resources/skills/seo-programmatic.md` | Programmatic SEO safeguards & quality gates |
| `resources/skills/seo-competitors.md` | Competitor comparison & alternatives page generation |
| `resources/skills/seo-github.md` | GitHub repo SEO: metadata, topics, README quality |

**Key Scripts:**
- `scripts/audit_runner.py` — Full audit → JSON + HTML + FULL-AUDIT-REPORT.md + ACTION-PLAN.md
- `scripts/pagespeed.py` — Core Web Vitals & PageSpeed Insights
- `scripts/crawl_audit.py` — Multi-page crawl for status, metadata, duplicates
- `scripts/parse_html.py` — Extract titles, metadata, headings, links, images, schema
- `scripts/validate_schema.py` — JSON-LD syntax and required fields check
- `scripts/indexability_matrix.py` — Per-URL indexability verdicts
- `scripts/sitemap_checker.py` — XML sitemap discovery, parsing, status
- `scripts/image_inventory.py` — Image alt text, dimensions, responsive images
- `scripts/robots_checker.py` — robots.txt crawler policy checks

**Rubric (required for all audits):** `resources/references/llm-audit-rubric.md`
Format: `Finding → Evidence → Impact → Fix` | Severity: `Critical / Warning / Pass / Info`

---

## 🗂️ How to Attach a Skill to an Agent

When defining a subagent, include the skill content in the `system_prompt` using:
```
Skill location: C:\Users\user\.gemini\antigravity\skills\seo\
Read the relevant sub-skill file before beginning work.
```

Or reference specific sub-skills by their full path.
